import React from "react";

const Landding = () => {
  return (
    <div>
      안녕 이봐 황산나래
    </div>
  );
};

export default Landding;
